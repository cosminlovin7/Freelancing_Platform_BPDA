#![no_std]

multiversx_sc::imports!();
multiversx_sc::derive_imports!();

mod freelancing_order;
mod freelancing_order_status;
mod freelancing_storage;

/// An empty contract. To be used as a template when starting a new contract from scratch.

#[multiversx_sc::contract]
pub trait FreelancingSmartContract:
    freelancing_storage::Storage    
{
    #[init]
    fn init(&self) {
        self.offer_counter().set(0u32)
    }
}
