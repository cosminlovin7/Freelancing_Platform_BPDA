multiversx_sc::imports!();
multiversx_sc::derive_imports!();

use super::freelancing_order_status::*;

#[derive(NestedEncode, NestedDecode, TopEncode, TopDecode, TypeAbi, Clone)]
pub struct Order<M: ManagedTypeApi> {
    pub offer_id: u32,
    pub employer_address: ManagedAddress<M>,
    pub employee_address: ManagedAddress<M>,
    pub offered_value: BigUint<M>,
    pub project_id: u32,
    pub status: OrderStatus,
    pub deadline: u64
}