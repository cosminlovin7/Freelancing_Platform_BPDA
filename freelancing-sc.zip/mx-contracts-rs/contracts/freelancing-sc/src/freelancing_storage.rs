multiversx_sc::imports!();
multiversx_sc::derive_imports!();

// mod freelancing_order;

use crate::freelancing_order::Order;

#[multiversx_sc::module]
pub trait Storage {
    #[view]
    #[storage_mapper("employee_offers")]
    fn employee_offers(&self, employee: &ManagedAddress) -> LinkedListMapper<u32>;

    #[view]
    #[storage_mapper("employer_offers")]
    fn employer_offers(&self, employer: &ManagedAddress) -> LinkedListMapper<u32>;

    #[view]
    #[storage_mapper("offer_counter")]
    fn offer_counter(&self) -> SingleValueMapper<u32>;

    #[view]
    #[storage_mapper("orders")]
    fn orders(&self, order_id: &u32) -> SingleValueMapper<Order<Self::Api>>;
}