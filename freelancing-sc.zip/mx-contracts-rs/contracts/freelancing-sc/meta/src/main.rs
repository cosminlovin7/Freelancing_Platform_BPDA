fn main() {
    multiversx_sc_meta::cli_main::<freelancing_sc::AbiProvider>();
}
